#include <conio.h>
#include <graphics.h>
#include <time.h>

void Draw(int x, int y, int color){
	setcolor(color);
	moveto(x, y);
	lineto(x, y+20);
	moveto(x,y);
	lineto(x-20, y);
	moveto(x,y);
	lineto(x, y-20);
	moveto(x,y);
	lineto(x+20, y);
	moveto(x,y);
	lineto(x+15, y+15);
	moveto(x,y);
	lineto(x-15, y+15);
	moveto(x,y);
	lineto(x-15, y-15);
	moveto(x,y);
	lineto(x+15, y-15);	
}

main()
{int size = 500;
initwindow(size, size);
srand(clock());
int x, y, color;
int A[size], B[size];
int RANDOM;
for(int i = 0; i<size; i++){
	A[i]=rand()%501;
	B[i] = rand()%501;
}
while(1){RANDOM = rand()%501;
x = A[RANDOM];
y = B[RANDOM];
Draw(x, y, rand()%16);
delay(1000);
Draw(x, y,0);
}
}
