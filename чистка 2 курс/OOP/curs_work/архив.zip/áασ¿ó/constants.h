#ifndef CONST_H
#define CONST_H


#define CIRCLE_RADIUS 12
#define RECTAN_SIZE 75
#define TRIAN_SIZE 40
#define ARR_SIZE 5


#endif

